# Lesson 07: Marking up and styling a page

- Create html file and HTML code
- Use CSS to style it
- Remember CSS reset and order of properties

## Task

Start marking up and styling the whole page. Use your previously made blueprint to do this

Don't worry about the form for now

![An image of a layout to practise HTML and CSS](homepage.jpg)